# task-3

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev
```

С помощью библиотеки jQuery замените текстовое содержимое элемента с id_toChange на изображение [https://i.pinimg.com/originals/e1/92/62/e1926225f3613de044c897241e60d47e.jpg](https://i.pinimg.com/originals/e1/92/62/e1926225f3613de044c897241e60d47e.jpg) шириной 400px и разместите указанный элемент по центру body
