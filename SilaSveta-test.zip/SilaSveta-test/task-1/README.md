# task-1

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev
```

Получите список объектов {file_id: file_size}, содержащий информацию о файлах, соответствующих следующим условиям:

1. Размер больше 2000000
2. Значение folder_name файла является null
3. Значение file не содержит в себе подстроку 'GENERATOR'

Полученный список должен быть отсортирован по полю file_size в порядке возрастания
