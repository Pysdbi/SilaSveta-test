# task-2

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev
```

В компоненте Vue получите из текущего URL [http://localhost:3000/?typeId=1&assetId=16](http://localhost:3000/?typeId=1&assetId=16) значение query-параметра assetId
