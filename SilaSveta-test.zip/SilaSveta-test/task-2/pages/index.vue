<template>
  <div class="app">
    <value-query-param
      param-name="assetId"
    />
  </div>
</template>

<script>
import ValueQueryParam from '../components/value-query-param'
export default {
  components: { ValueQueryParam }
}
</script>

<style>

</style>
